<?php
/**
 * Rusbi Books - cPanel Configuration & MySQL Database Settings
 */

define('DB_DRIVER', 'mysql'); // Activated cPanel MySQL

// SQLite Path (Fallback)
define('SQLITE_FILE', __DIR__ . '/data/books.sqlite');

// cPanel MySQL Credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'jausdsywh1_rusbi');
define('DB_USER', 'jausdsywh1_rusbi');
define('DB_PASS', 'Damian1937$$');
define('DB_PORT', 3306);

// ============================================================
// SMTP Outgoing Mailer Configuration (cPanel Webmail)
// ============================================================
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'mail.rusbibooks.systemslib.com');
define('SMTP_PORT', 465);                              // 465 for SSL, 587 for TLS
define('SMTP_SECURE', 'ssl');                          // 'ssl' or 'tls'
define('SMTP_USER', 'admin@rusbibooks.systemslib.com'); // cPanel Webmail email
define('SMTP_PASS', 'Damian1937$$');                   // Webmail password
define('SMTP_FROM_EMAIL', 'admin@rusbibooks.systemslib.com');
define('SMTP_FROM_NAME', 'Rusbi Group of Companies Ltd');


